<?php
$host = 'localhost';
$db   = 'clientes_db';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

$stmt = $pdo->prepare("SELECT * FROM clientes");
$stmt->execute();
$clients = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$clients) {
    header('HTTP/1.1 400 Bad Request');
    die('No hay datos de clientes');
}

$html = '<html><head><style>
            table { width: 100%; border-collapse: collapse; }
            th, td { border: 1px solid black; padding: 8px; text-align: left; }
            th { background-color: #f2f2f2; }
        </style></head><body>';
$html .= '<h2>Lista de Clientes</h2>';
$html .= '<table>';
$html .= '<tr>';
$html .= '<th>Nombre</th>';
$html .= '<th>Apellido</th>';
$html .= '<th>Tipo de Documento</th>';
$html .= '<th>Numero de Documento</th>';
$html .= '<th>Ciudad</th>';
$html .= '<th>Direccion</th>';
$html .= '<th>Telefono</th>';
$html .= '<th>Email</th>';
$html .= '</tr>';

foreach ($clients as $client) {
    $html .= '<tr>';
    $html .= '<td>' . $client['nombre'] . '</td>';
    $html .= '<td>' . $client['apellido'] . '</td>';
    $html .= '<td>' . $client['tipoDocumento'] . '</td>';
    $html .= '<td>' . $client['numeroDocumento'] . '</td>';
    $html .= '<td>' . $client['ciudad'] . '</td>';
    $html .= '<td>' . $client['direccion'] . '</td>';
    $html .= '<td>' . $client['telefono'] . '</td>';
    $html .= '<td>' . $client['email'] . '</td>';
    $html .= '</tr>';
}
$html .= '</table>';
$html .= '</body></html>';

$tempHtmlFile = tempnam(sys_get_temp_dir(), 'clientes') . '.html';
file_put_contents($tempHtmlFile, $html);

$pdfFile = tempnam(sys_get_temp_dir(), 'clientes') . '.pdf';
exec("wkhtmltopdf $tempHtmlFile $pdfFile");

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="clientes_' . date('Y-m-d_H-i-s') . '.pdf"');
readfile($pdfFile);

unlink($tempHtmlFile);
unlink($pdfFile);
exit;