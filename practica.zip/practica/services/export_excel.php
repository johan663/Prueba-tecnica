<?php
$host = 'localhost';
$db   = 'clientes_db';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}

$stmt = $pdo->prepare("SELECT * FROM clientes");
$stmt->execute();
$clients = $stmt->fetchAll(PDO::FETCH_ASSOC);


if (!$clients) {
    header('HTTP/1.1 400 Bad Request');
    die('No hay datos de clientes');
}

$html = '';
$html .= '<table border="1">';
$html .= '<tr>';
$html .= '<td colspan="8">Lista de Clientes</td>';
$html .= '</tr>';
$html .= '<tr>';
$html .= '<td><b>Nombre</b></td>';
$html .= '<td><b>Apellido</b></td>';
$html .= '<td><b>Tipo de Documento</b></td>';
$html .= '<td><b>Numero de Documento</b></td>';
$html .= '<td><b>Ciudad</b></td>';
$html .= '<td><b>Direccion</b></td>';
$html .= '<td><b>Telefono</b></td>';
$html .= '<td><b>Email</b></td>';
$html .= '</tr>';

foreach ($clients as $client) {
    $html .= '<tr>';
    $html .= '<td>' . $client['nombre'] . '</td>';
    $html .= '<td>' . $client['apellido'] . '</td>';
    $html .= '<td>' . $client['tipoDocumento'] . '</td>';
    $html .= '<td>' . $client['numeroDocumento'] . '</td>';
    $html .= '<td>' . $client['ciudad'] . '</td>';
    $html .= '<td>' . $client['direccion'] . '</td>';
    $html .= '<td>' . $client['telefono'] . '</td>';
    $html .= '<td>' . $client['email'] . '</td>';
    $html .= '</tr>';
}
$html .= '</table>';

header("Expires: Mon, 26 Jul 2227 05:00:00 GMT");
header("Last-Modified: " . gmdate("D,d M YH:i:s") . " GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pragma: no-cache");
header("Content-type: application/x-msexcel");
header('Content-Disposition: attachment; filename="clientes_' . date('Y-m-d_H-i-s') . '.xls"');
header("Content-Description: PHP Generado Data");


echo $html;
exit;