document.getElementById("clientForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const submitButton = document.querySelector(
    '#clientForm button[type="submit"]'
  );
  if (submitButton.textContent === "Actualizar Cliente") {
    updateClient();
  } else {
    addClient();
  }
});

let editIndex = null;

function getClients() {
  return fetch("methods/get_clients.php")
    .then((response) => response.json())
    .then((data) => {
      if (!data.clients) {
        throw new Error("No se encontraron clientes.");
      }
      return data.clients;
    });
}

function saveClients(clients) {}

function addClient() {
  const newClient = {
    nombre: document.getElementById("nombre").value,
    apellido: document.getElementById("apellido").value,
    tipoDocumento: document.getElementById("tipoDocumento").value,
    numeroDocumento: document.getElementById("numeroDocumento").value,
    ciudad: document.getElementById("ciudad").value,
    direccion: document.getElementById("direccion").value,
    telefono: document.getElementById("telefono").value,
    email: document.getElementById("email").value,
  };
  fetch("methods/add_client.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(newClient),
  }).then(() => {
    displayClients();
    document.getElementById("clientForm").reset();
  });
}

function displayClients() {
  getClients().then((clients) => {
    const tableBody = document
      .getElementById("clientTable")
      .getElementsByTagName("tbody")[0];
    tableBody.innerHTML = "";

    clients.forEach((client) => {
      const row = tableBody.insertRow();
      for (let key in client) {
        if (key !== "id") {
          let cell = row.insertCell();
          cell.textContent = client[key];
        }
      }
      let actionCell = row.insertCell();
      actionCell.innerHTML = `
        <button class="edit-btn" onclick="editClient(${client.id})">
          <i class="fas fa-edit"></i>
        </button>
        <button class="delete-btn" onclick="deleteClient(${client.id})">
          <i class="fas fa-trash-alt"></i>
        </button>
      `;
    });
  });
}

function editClient(id) {
  getClients().then((clients) => {
    const client = clients.find((c) => Number(c.id) === Number(id));
    if (!client) {
      console.error(`Cliente con ID ${id} no encontrado.`);
      return;
    }
    console.log("Datos del cliente a editar:", client);
    document.getElementById("nombre").value = client.nombre;
    document.getElementById("apellido").value = client.apellido;
    document.getElementById("tipoDocumento").value = client.tipoDocumento;
    document.getElementById("numeroDocumento").value = client.numeroDocumento;
    document.getElementById("ciudad").value = client.ciudad;
    document.getElementById("direccion").value = client.direccion;
    document.getElementById("telefono").value = client.telefono;
    document.getElementById("email").value = client.email;
    document.querySelector('#clientForm button[type="submit"]').textContent =
      "Actualizar Cliente";
    editIndex = id;
  });
}

function updateClient() {
  const updatedClient = {
    id: editIndex,
    nombre: document.getElementById("nombre").value,
    apellido: document.getElementById("apellido").value,
    tipoDocumento: document.getElementById("tipoDocumento").value,
    numeroDocumento: document.getElementById("numeroDocumento").value,
    ciudad: document.getElementById("ciudad").value,
    direccion: document.getElementById("direccion").value,
    telefono: document.getElementById("telefono").value,
    email: document.getElementById("email").value,
  };
  fetch("methods/update_client.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(updatedClient),
  }).then(() => {
    displayClients();
    document.getElementById("clientForm").reset();
    document.querySelector('#clientForm button[type="submit"]').textContent =
      "Agregar Cliente";
    editIndex = null;
  });
}

function deleteClient(id) {
  fetch("methods/delete_client.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ id }),
  }).then(() => {
    displayClients();
  });
}

function exportExcel() {
  fetch("services/export_excel.php", {
    method: "GET",
  })
    .then((response) => response.blob())
    .then((blob) => {
      const link = document.createElement("a");
      link.href = window.URL.createObjectURL(blob);
      link.download = "clientes.xls";
      link.click();
    })
    .catch((error) => {
      console.error("Error al exportar Excel:", error);
      alert("Error al generar el archivo Excel");
    });
}

function exportPDF() {
  fetch("services/export_pdf.php", {
    method: "GET",
  })
    .then((response) => response.blob())
    .then((blob) => {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `clientes_${new Date().toISOString().slice(0, 10)}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    })
    .catch((error) => {
      console.error("Error al exportar PDF:", error);
      alert("Error al generar el PDF");
    });
}

document.querySelector(".export.pdf").addEventListener("click", function (e) {
  e.preventDefault();
  exportPDF();
});

document.querySelector(".export.xlsx").addEventListener("click", function (e) {
  e.preventDefault();
  exportExcel();
});

displayClients();
