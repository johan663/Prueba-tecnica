<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clientes_db";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}


$data = json_decode(file_get_contents("php://input"), true);

$sql = "UPDATE clientes SET 
    nombre='{$data['nombre']}', 
    apellido='{$data['apellido']}', 
    tipoDocumento='{$data['tipoDocumento']}', 
    numeroDocumento='{$data['numeroDocumento']}', 
    ciudad='{$data['ciudad']}', 
    direccion='{$data['direccion']}', 
    telefono='{$data['telefono']}', 
    email='{$data['email']}' 
    WHERE id={$data['id']}";

if ($conn->query($sql) === TRUE) {
    echo "Cliente actualizado exitosamente";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
