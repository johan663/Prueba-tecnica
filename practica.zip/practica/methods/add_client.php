<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "clientes_db";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}


$data = json_decode(file_get_contents("php://input"), true);

$sql = "INSERT INTO clientes (nombre, apellido, tipoDocumento, numeroDocumento, ciudad, direccion, telefono, email)
VALUES ('{$data['nombre']}', '{$data['apellido']}', '{$data['tipoDocumento']}', '{$data['numeroDocumento']}', '{$data['ciudad']}', '{$data['direccion']}', '{$data['telefono']}', '{$data['email']}')";

if ($conn->query($sql) === TRUE) {
    echo "Nuevo cliente agregado exitosamente";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
